# Mosh Weekly Study Routine App

A simple, self-contained weekly study tracker for IJMB prep (Maths, Physics, Chemistry). No build step, no dependencies — it's a single `index.html` file that runs entirely in the browser and saves your checked-off progress locally on your device.

## Deploying it for free on GitHub Pages

**1. Create a new GitHub repository**
- Go to [github.com/new](https://github.com/new)
- Name it something like `mosh-study-routine`
- Set it to **Public** (GitHub Pages needs this on the free tier)
- Click **Create repository**

**2. Upload the file**
- On your new repo's page, click **Add file → Upload files**
- Drag in `index.html` from this folder
- Commit the change (the default commit message is fine)

**3. Turn on GitHub Pages**
- Go to your repo's **Settings** tab
- In the left sidebar, click **Pages**
- Under "Build and deployment" → "Source", choose **Deploy from a branch**
- Under "Branch", choose `main` and folder `/ (root)`, then **Save**

**4. Get your live link**
- Wait about 1–2 minutes, then refresh the Pages settings screen
- Your app will be live at:
  `https://<your-github-username>.github.io/<repo-name>/`
  e.g. `https://mosh.github.io/mosh-study-routine/`

That's it — no server, no cost, and it updates automatically every time you push a new version of `index.html`.

## Using it day to day

- Open the link (bookmark it, or add it to your phone's home screen for an app-like feel)
- Tap through the day tabs (Mon–Sun) to see that day's blocks
- Check off tasks as you complete them — this saves automatically in your browser
- Progress is stored **locally per device/browser**, so it won't sync between your phone and laptop unless you visit the same link and browser on both

## Editing the schedule

Everything — days, times, subjects, task descriptions — lives in one JavaScript object near the top of the `<script>` section in `index.html`, called `DATA`. Open the file in any text editor, find the day you want to change (e.g. `mon: { ... }`), and edit the `time`, `subject`, `title`, or `desc` fields directly. Save the file, re-upload it to GitHub (or push via git), and the live site updates.

## Optional: pushing updates via git instead of the web UI

If you'd rather use git locally:

```bash
git clone https://github.com/<your-username>/mosh-study-routine.git
cd mosh-study-routine
# copy your updated index.html in here
git add index.html
git commit -m "Update study routine"
git push
```

GitHub Pages will redeploy automatically within a minute or two of the push.
